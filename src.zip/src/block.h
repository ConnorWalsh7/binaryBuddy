/*
 * block.h
 *
 *  Created on: 2015-03-29
 *      Author: connor
 */

#ifndef BLOCK_H_
#define BLOCK_H_

struct Block
{
	int block_base;
	int block_size;
};

#endif /* BLOCK_H_ */
